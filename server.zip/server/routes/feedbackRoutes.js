// server/routes/feedbackRoutes.js
const express = require('express');
const router = express.Router();
const { pool } = require('../db');
const authMiddleware = require('../middleware/authMiddleware'); // require login

// POST feedback
router.post('/', authMiddleware, async (req, res) => {
  try {
    const sender = req.user && req.user.user_id;
    const { receiver_user_id, score, comment } = req.body;
    if (!sender) return res.status(401).json({ error: 'Unauthorized' });
    if (!receiver_user_id || !score) return res.status(400).json({ error: 'Missing fields' });

    const q = `INSERT INTO feedback (sender_user_id, receiver_user_id, score, comment, created_on)
               VALUES ($1,$2,$3,$4, NOW()) RETURNING *`;
    const r = await pool.query(q, [sender, receiver_user_id, score, comment || null]);
    return res.json({ feedback: r.rows[0] });
  } catch (err) {
    console.error('Feedback insert error', err);
    return res.status(500).json({ error: 'DB error' });
  }
});

// GET feedback (list or by faculty)
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { faculty_id, limit } = req.query;
    const params = [];
    let q = `SELECT f.*, u.display_name as sender_name FROM feedback f
             LEFT JOIN users u ON u.user_id = f.sender_user_id`;
    if (faculty_id) {
      params.push(faculty_id);
      q += ` WHERE f.receiver_user_id = $${params.length}`;
    }
    q += ` ORDER BY f.created_on DESC`;
    if (limit) q += ` LIMIT ${parseInt(limit, 10) || 50}`;

    const r = await pool.query(q, params);
    return res.json({ feedback: r.rows });
  } catch (err) {
    console.error('Feedback fetch error', err);
    return res.status(500).json({ error: 'DB error' });
  }
});

// optional: feedback summary (avg)
router.get('/summary', authMiddleware, async (req, res) => {
  try {
    const { faculty_id } = req.query;
    if (!faculty_id) return res.status(400).json({ error: 'faculty_id required' });
    const r = await pool.query('SELECT AVG(score) as avg, COUNT(*) as count FROM feedback WHERE receiver_user_id=$1', [faculty_id]);
    return res.json({ avg: Number(r.rows[0].avg) || 0, count: Number(r.rows[0].count) || 0 });
  } catch (err) {
    console.error('Feedback summary error', err);
    return res.status(500).json({ error: 'DB error' });
  }
});

module.exports = router;
